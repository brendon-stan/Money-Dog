# Money Dog

This is main overview and set of features. For technical documentation and start-up guide please see
TEC-DOCS.md in this some folder.

# Problem Statement
Many people find it hard to accurately budget their money. Even someone has a planed budget it can
take a lot of effort to record all transactions to stay out of the red. Money Dog mains to keep
help simplify this process has being a convent way to track spending and balance the books on the
fly!

# Overview
Money Dog is designed to be a personal money management system. It helps users track where their hard
earned dollars are going so they can save for what matters in their lives.

This is done though a budgeting tool. Users can set up spending buckets and add money to those buckets.
These buckets represent categories such as groceries, gas, utilities, rent, mortgage, insurance, emergency
funds, fun-money, car payments, or concert tickets. Users can add and remove money from these buckets
as they spend and earn.

For example for a user gets paid on $1000 on the 1st and 15th of every month they can set up Money Dog
to automatically put $500 into rent, $100 into utilities, $50 into groceries, $50 into concerts, $100
into emergency funds, $75 into fun-money, $25 into gas, and $100 into savings on the days they get paid.

As the user goes about their day and spends they can then remove those funds from the corresponding
bucket. So if today you got paid and added $25 into the gas bucket then got a full tank spending $10
the gas bucket would reflect that is has a balance of $15.

# Technical Design Overview
This project was started as a way to learn UI skills with JavaScrip and the Angular framework. Django
is a great web-app platform to build from and is native in Python making it an ideal for backend work
while Angular JavaScript is the de facto standard for modern front end design.

As such any logic that can be implemented in the front or backend should be done so in the frontend.

To better understand how to build a UI that requires user lots of user selection, configuration, and
management this project was born.

Again this was built as a learning project - specifically to prepare for NSO UI work with NSO. Hence
allowing those that work on Money Dog to be better front end developers allowing for skill growth in 
a live environment.

# Project Objective
As stated above Money Dog has three maims:
1) Be a living lab for engineers and developers to practice UI skills on a "real" project with defined
features and objectives. Allowing for skill growth and testing of new ideas in a more practical setting
before being put to a billable project.

2) While being a leaning tool have the design requirements of a true project to allow for more realistic
learning growth. This allows means that the features defines in the 0.1 release were created before
any code was written (well before almost any code was written). Such more engineers or developers 
need to grow skills in front end dev (or back end, or deployment, or security) they can add a new
set of features below and begin learning!

3) Set a standard for how to document code. Many have at one point or another found
that documentation tends to be lacking. Both internally and in the networking/telecommunications sector
as a hole. Money Dog will have two main points of documentation this (the README) and TECH-DOCS. The 
README will provide overview on the nature of the project and define all features. The README will
a doc that an internal or client manger would want to review. The TECH-DOCS will for anyone actually
working to add code to the project. Again, a document for high level design at a management level and a
second document for low level technical discussion. Before code is writen for a feature that feature
should be clearly defined here. During and after the completion of a feature the designer(s) should
add to technical docs providing notes, issues, potential bugs, suggested future changes, and info 
regarding design decisions (I did a like this because x, y, and z).

# Feature set

# 0.1
## First feature set
## Defined 21 July 2020

##### Notes on Feature set 0.1
At this time UI learning is the most important so many common place web-app features will not be
implemented. Focus will be on added features that require JavaScript

### User

---
##### - register/ 
- a button can be seen from anywhere on website when not logged in to go here
- a new user can register for an account

##### - login/  
- a button can be seen from anywhere on website when not logged in to go here
- an existing user can sign into an account
- once logged in a user can only see information regarding to their account
- once logged in a user can only edit information regarding to their account

##### - logout/
- a button can be seen from anywhere on website when logged in to go here
- a logged in user can log out

SCHEMA:
- username
- first name
- last name
- email
- password

### Bucket

---

- a bucket is a category in which a user can spend money
- a user can have up to 10 buckets (limited now for screen space)
- when a list-view of transactions posted under a bucket is displayed the user can hover mouse over
to and see a "edit" button to make changes to that transaction (takes to "expense-modify/*expenseID*")
- all transaction showing will be displayed in a column form of debt/credit

##### - buckets/new/
- user can create a new bucket
- user will define the name
- user can set a default value 

##### - buckets/view-all-buckets/ 
- a button can be see anywhere on a user dash board when logged on to go here
- a user can get to view all buckets from a dash-board button
- a user can view all buckets that is associated to their account
- a bucket will appear red if it has a negative balance
- a user will be able to select a buck and the last 10 transactions (by date of transaction) to be 
shown under bucket
- a user can "see details" of a bucket (takes to "buckets/view-bucket/*bucketID* ")
- a user can edit transactions via a button taking them to "expense/assign-to-bucket/"

##### - buckets/view-bucket/*bucketID* 
- can get to bucket by a user clicking on a bucket from "view-all-buckets/"
- a user can create, edit, or delete a bucket (goes to "bucket/edit/*bucketID*")
- a bucket's balance will be the sum of all debits/credits posted to it
- a user will be able to see all transactions filtered by month
- a user can select transactions and move them to another bucket. User can submit changes and the 
new balance of the bucket the transactions where moved to will be displayed as a banner message 

##### - bucket/edit/*bucketID*
- can change the name of the bucket


SCHEMA:
- name
- ID (auto)
- user (back ref)
- balance (default = 0)
- date created
- last modified
- last transaction


### Expenses

---

- a user can creat an expense; i.e. a debit transaction - this expense will be tied to the user in
the schema
- a user can assign an expense to a bucket
- a user can edit or delete an expense

##### - expenses/create-new
- a button saying "Create expenses" can be seen from anywhere on the website one a user logged in
from a dash board view
- a user can creat expenses in a dedicated window - up to 5 at a time (for simplicity)
- in the expense creation the user can click a "add another expense" button to creat a new expense
- when the "add another expense" button is click the form will expand to show a new expense field(s)
- once all (up to 10) expenses are added the user can submit. Form will not be submitted with all 
expense(s) until the submit button is pressed
- when submit is clicked page will redirect to "move-transactions/"

##### - expense/assign-to-bucket/
- all buckets will be displayed in a grid patten of two rows. Rows will can contain the following 
buckets based on total number of buckets (rows top to bottom of page):
10: 5, 5
9: 5, 4
8: 4, 4
7: 4, 3
6: 3, 3
5: 3, 2
4: 2, 2
3: 2, 1
2: 1, 1
1: 1
0: a button saying "Create New Bucket" will take user to "bucket-new-/"

- each bucket will have its current balance displayed near it
- all queued expenses will appear one at a time at the top of the screen
- the user can then drop a drop expenses under the desired bucket
- if this is the first time a user has been to "move-transactions/" this then a banner message 
saying "Drag and drop the expense to the desired bucket will be displayed"
- as expenses are placed under buckets they will remain their for viewing
- once an expense is placed in a bucket it can be dropped and dropped to another bucket
- if this is the first time a user has been to "move-transactions/" this then a banner message will
 be displayed saying "Expenses can dragged from one bucket to anther"
- as expenses are placed under buckets the new balance of the bucket will be updated
- if a bucket has a negative balance then the bucket will turn red

##### -expense/modify/*expenseID*
- a user can edit the name, date posted, bucketOwner, or amount of an expense
- a user can delete an expense


SCHEMA:
- name
- ID (auto)
- user (back ref)
- date created
- date posted (i.e. when the transaction occurred in real life)
- bucketOwner (back-ref)
- amount ($)


### Income

---

- a user can define an income that will be added to buckets
- income can be auto added to buckets at defined intervals; i.e. paydays
- income can be auto divided on paydays buckets be either % or $ amounts

##### - income/create-income-source/
- a payday is a predefined interval when income will be added to buckets
- user set a name for the income source
- a user can select if this is a reoccurring payment (monthly, semi-monthly)
- if reoccurring user will set frequency and what day the payday occurs; i.e. for monthly on the 
1st, for semi-monthly the 1st and 15th of every month
- it will be a separate apps job to ensure that events are triggered on a payday
- the user will select this by click date(s) on a calender with the 1st-31st displayed
- user will submit form and be taken to "income-allocation/*income*"

##### - income/assign-income-source-allocation/*incomeID*
- user will be shown a 5xn+1 grid where n is the number of buckets
- columns will be "Bucket Name", "Current Balance", "Added Amount ($)", "Percentage of Income (%)", "New Balance"
- the rows will be each bucket
- the +1 will be a final row under "Added Amount ($)" showing "Income Balance Remaining"
- The user can then add money to a bucket by entering an amount into the "Added Amount Cell ($)"
- As user types the value of the "Percentage of Income (%) cell" will reflect the actual percentage
of the amount being added to the account rounded to the nearest 0.01%
- As the user types the value of the "Added Amount ($)" the "New Balance" for that row will be updated
- As the user type the value of "Income Balance Remaining" will reflect changes in that column
- All values must be positive
- All of the income must be allocated such that "Income Balance Remaining" is $0.00
- Once all income is allocated the income source then be submitted

##### -income/income-source-edit/*incomeID*
- user can edit the income-source
- user can change frequency and payday selection
- user can change payday amount and name

#####-income/income-allocation-edit/*incomeID*
- a user can edit the assign-income-allocation form
