from django.shortcuts import render, redirect
from .forms import *
from .models import *
from django.contrib.messages.views import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import CreateView
from django.contrib.auth.decorators import login_required


def homePage(requests):
    return render(requests, 'Main/homePage.html', {"title": "Home"})


def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f'Your account has been created! You are now able to log in')
            return redirect('login')
    else:
        form = UserRegisterForm()
    return render(request, 'Main/register.html', {'form': form})


@login_required()
def newBucket(request):
    form = NewBucketForm
    if request.method == "POST":
        data = request.POST
        print(data)

        return redirect('main-newBucket')

    else:
        return render(request, 'Main/newBucket.html', {'form': form})
