from django.urls import path
from .views import *

urlpatterns = [
    path('', homePage, name='main-home'),
    path('register/', register, name='main-register'),
    path('buckets/new/', newBucket, name='main-newBucket')
]
