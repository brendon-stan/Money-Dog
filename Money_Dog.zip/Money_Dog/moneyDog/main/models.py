from django.db import models
from annoying.fields import AutoOneToOneField
from django.contrib.auth.models import User
from django.urls import reverse

import datetime


class Account(models.Model):
    user = AutoOneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.user.username} Profile'


class Buckets(models.Model):
    name = models.CharField(max_length=64, unique=True, blank=False, null=False, help_text='Sent a nick-name for this bucket like "gas" or "rent"')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    balance = models.FloatField(default=0, blank=True, null=False, help_text='Set starting balance of Bucket')
    dateCreated = models.DateTimeField(default=datetime.datetime.now())
    dateModified = models.DateTimeField(default=datetime.datetime.now())
    lastTransaction = models.DateTimeField(default=datetime.datetime.now())

    def get_absolute_url(self):
        return reverse('device-detail', kwargs={'pk': self.pk})
